<?php
/*******************************************************************
* Adds a box to the main column on the Post and Page edit screens.*
*******************************************************************/
function facebook_master_add_custom_box() {
$screens = array( 'post', 'page' );
	foreach ( $screens as $screen ) {
		add_meta_box(
			'facebook_master_sectionid',
			__( 'Facebook Master Shortcode [facebook-master]', 'facebook_master_shortcode' ),
			'facebook_master_inner_custom_box',
			$screen
		);
	}
}
add_action( 'add_meta_boxes', 'facebook_master_add_custom_box' );

/**
 * Prints the box content.
 *
 * @param WP_Post $post The object for the current post/page.
 */
function facebook_master_inner_custom_box( $post ) {

  // Add an nonce field so we can check for it later.
  wp_nonce_field( 'facebook_master_inner_custom_box', 'facebook_master_inner_custom_box_nonce' );

  /*
   * Use get_post_meta() to retrieve an existing value
   * from the database and use the value for the form.
   */
	$facebook_master_preview = get_post_meta( $post->ID, 'facebook_master_preview', true );
	$facebook_master_align = get_post_meta( $post->ID, 'facebook_master_align', true );
	$facebook_master_w = get_post_meta( $post->ID, 'facebook_master_w', true );
	$facebook_master_h = get_post_meta( $post->ID, 'facebook_master_h', true );
	$facebook_master_display = get_post_meta( $post->ID, 'facebook_master_display', true );
	$facebook_master_link = get_post_meta( $post->ID, 'facebook_master_link', true );
	$facebook_master_id = get_post_meta( $post->ID, 'facebook_master_id', true );
	$facebook_master_header = get_post_meta( $post->ID, 'facebook_master_header', true );
	$facebook_master_faces = get_post_meta( $post->ID, 'facebook_master_faces', true );
	$facebook_master_stream = get_post_meta( $post->ID, 'facebook_master_stream', true );
	$facebook_master_color = get_post_meta( $post->ID, 'facebook_master_color', true );
	$facebook_master_border = get_post_meta( $post->ID, 'facebook_master_border', true );
?>
	<img src="<?php echo plugins_url('../images/techgasp-minilogo-16.png', __FILE__); ?>" style="float:left; height:16px; vertical-align:middle;" />
	&nbsp;
	<input type="checkbox" <?php checked( (bool) $facebook_master_display, true ); ?> id="facebook_master_display" name="facebook_master_display" />
	<label for="facebook_master_display"><b><?php _e('Display Social Plugin: ', 'facebook_master_shortcode'); ?></b></label>
	<br>
	<br>
	<label for="facebook_master_link"><?php _e('Facebook Fan Page Link: ', 'facebook_master_shortcode'); ?></label>
	<input id="facebook_master_link" name="facebook_master_link" value="<?php echo $facebook_master_link ?>" style="width:195px;" />
	<div class="description">Facebook Fan Page Link, ie.</div>
	<div class="description"><b>https://www.facebook.com/techgasp</b></div>
	<br>
	<label for="facebook_master_id"><?php _e('optional, Facebook App ID: ', 'facebook_master_shortcode'); ?></label>
	<input id="facebook_master_id" name="facebook_master_id" value="<?php echo $facebook_master_id ?>" style="width:189px;" />
	<div class="description">if you have a Facebook Application associated</div>
	<div class="description">with your Fan Page, insert APP ID number here</div>
	<br>
	<img src="<?php echo plugins_url('../images/techgasp-minilogo-16.png', __FILE__); ?>" style="float:left; height:16px; vertical-align:middle;" />
	&nbsp;
	<input type="checkbox" <?php checked( (bool) $facebook_master_header, true ); ?> id="facebook_master_header" name="facebook_master_header" />
	<label for="facebook_master_header"><b><?php _e('Display Plugin Header: ', 'facebook_master_shortcode'); ?></b></label>
	<br>
	<img src="<?php echo plugins_url('../images/techgasp-minilogo-16.png', __FILE__); ?>" style="float:left; height:16px; vertical-align:middle;" />
	&nbsp;
	<input type="checkbox" <?php checked( (bool) $facebook_master_faces, true ); ?> id="facebook_master_faces" name="facebook_master_faces" />
	<label for="facebook_master_faces"><b><?php _e('Display Facebook User Faces: ', 'facebook_master_shortcode'); ?></b></label>
	<br>
	<img src="<?php echo plugins_url('../images/techgasp-minilogo-16.png', __FILE__); ?>" style="float:left; height:16px; vertical-align:middle;" />
	&nbsp;
	<input type="checkbox" <?php checked( (bool) $facebook_master_stream, true ); ?> id="facebook_master_stream" name="facebook_master_stream" />
	<label for="facebook_master_stream"><b><?php _e('Display Facebook Stream: ', 'facebook_master_shortcode'); ?></b></label>
	<br>
	<img src="<?php echo plugins_url('../images/techgasp-minilogo-16.png', __FILE__); ?>" style="float:left; height:16px; vertical-align:middle;" />
	&nbsp;
	<input type="checkbox" <?php checked( (bool) $facebook_master_color, true ); ?> id="facebook_master_color" name="facebook_master_color" />
	<label for="facebook_master_color"><b><?php _e('Color Scheme: ', 'facebook_master_shortcode'); ?></b></label>
	<div class="description">Color Scheme: if activated Light, if disabled Dark</div>
	<img src="<?php echo plugins_url('../images/techgasp-minilogo-16.png', __FILE__); ?>" style="float:left; height:16px; vertical-align:middle;" />
	&nbsp;
	<input type="checkbox" <?php checked( (bool) $facebook_master_border, true ); ?> id="facebook_master_border" name="facebook_master_border" />
	<label for="facebook_master_border"><b><?php _e('Display Plugin Border: ', 'facebook_master_shortcode'); ?></b></label>
	<br>
	<br>
	<img src="<?php echo plugins_url('../images/techgasp-minilogo-16.png', __FILE__); ?>" style="float:left; height:16px; vertical-align:middle;" />
	&nbsp;
	<label for="facebook_master_align"><b><?php _e('Align Facebook Master: ', 'facebook_master_shortcode'); ?></b></label>
	<br>
	<input id="facebook_master_player_align" name="facebook_master_align" value="<?php echo $facebook_master_align ?>" style="width:50px;" />
	<label for="facebook_master_align"><?php _e(' left or right, leave blank for none', 'facebook_master_shortcode'); ?></label>
	<br>
	<input id="facebook_master_w" name="facebook_master_w" value="<?php echo $facebook_master_w ?>" style="width:50px;" />
	<label for="facebook_master_w"><?php _e('Shortcode Width', 'facebook_master_shortcode'); ?></label>
	<br>
	<input id="facebook_master_h" name="facebook_master_h" value="<?php echo $facebook_master_h ?>" style="width:50px;" />
	<label for="facebook_master_h"><?php _e('Shortcode Height', 'facebook_master_shortcode'); ?></label>
	<div class="description">Width value recommended by Facebook <b>300</b>.</div>
	<div class="description">Height value recommended by Facebook to display 10 faces <b>560</b>.</div>
	<div class="description"><b>Leave the above 3 values empty for Mobile Responsiveness</b>.</div>
	<div class="description">More about these settings, <a href="http://wordpress.techgasp.com/facebook-master-documentation/" target="_blank">documentation</a>.</div>
	<br>
<div style="background: url(<?php echo plugins_url('../images/techgasp-hr.png', __FILE__); ?>) repeat-x; height: 10px"></div>
	<br>
	<img src="<?php echo plugins_url('../images/techgasp-minilogo-16.png', __FILE__); ?>" style="float:left; height:16px; vertical-align:middle;" />
	&nbsp;
	<input type="checkbox" <?php checked( (bool) $facebook_master_preview, true ); ?> id="facebook_master_preview" name="facebook_master_preview" />
	<label for="facebook_master_preview"><b><?php _e('Facebook Master Preview: ', 'facebook_master_shortcode'); ?></b></label>
	<br>
<?php
if ( $facebook_master_preview ){
	// Display Facebook Header
		if ( $facebook_master_header == "on" ) 
		$facebook_master_header = "true";
		else {
		$facebook_master_header = "false";
		}
	// Display Facebook Faces
		if ( $facebook_master_faces == "on" ) 
		$facebook_master_faces = "true";
		else {
		$facebook_master_faces = "false";
			}
	// Display Facebook Stream
		if ( $facebook_master_stream == "on" ) 
		$facebook_master_stream = "true";
		else {
		$facebook_master_stream = "false";
			}
	// Display Facebook Color
		if ( $facebook_master_color == "on" ) 
		$facebook_master_color = "light";
		else {
		$facebook_master_color = "dark";
			}
	// Display Facebook Border
		if ( $facebook_master_border == "on" ) 
		$facebook_master_border = "true";
		else {
		$facebook_master_border = "false";
			}

		if ( $facebook_master_display == "on" ){
		$facebook_master_spacer = "'";
		echo '<div class="fb-like-box" data-href="'.$facebook_master_link.'" width="'.$facebook_master_w.'" height="'.$facebook_master_h.'" data-show-faces="'.$facebook_master_faces.'" data-colorscheme="'.$facebook_master_color.'" data-stream="'.$facebook_master_stream.'" data-show-border="'.$facebook_master_border.'" data-header="'.$facebook_master_header.'"></div>' .
			'<div id="fb-root"></div>' .
			'<script>(function(d, s, id) {' .
			'var js, fjs = d.getElementsByTagName(s)[0];' .
			'if (d.getElementById(id)) return;' .
			'js = d.createElement(s); js.id = id;' .
			'js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId='.$facebook_master_id.'";' .
			'fjs.parentNode.insertBefore(js, fjs);' .
			'}(document, '.$facebook_master_spacer.'script'.$facebook_master_spacer.', '.$facebook_master_spacer.'facebook-jssdk'.$facebook_master_spacer.'));</script>';
		}
		else{
		}
}
?>
	<h2><img src="<?php echo plugins_url('../images/techgasp-minilogo.png', __FILE__); ?>" style="width:40px; vertical-align:middle;" alt="' . esc_attr__( 'TechGasp Plugins') . '" /><b> Facebook Master Website</b></h2>
	<p><a class="button-secondary" href="http://wordpress.techgasp.com/facebook-master/" target="_blank" title="Facebook Master Info Page">Info Page</a> <a class="button-secondary" href="http://wordpress.techgasp.com/facebook-master-documentation/" target="_blank" title="Facebook Master Documentation">Documentation</a> <a class="button-primary" href="http://wordpress.org/plugins/facebook-master/" target="_blank" title="Facebook Master Wordpress">RATE US *****</a></p>
<?php
}
/**
 * When the post is saved, saves our custom data.
 *
 * @param int $post_id The ID of the post being saved.
 */
function facebook_master_save_postdata( $post_id ) {

  /*
   * We need to verify this came from the our screen and with proper authorization,
   * because save_post can be triggered at other times.
   */

  // Check if our nonce is set.
  if ( ! isset( $_POST['facebook_master_inner_custom_box_nonce'] ) )
    return $post_id;

  $nonce = $_POST['facebook_master_inner_custom_box_nonce'];

  // Verify that the nonce is valid.
  if ( ! wp_verify_nonce( $nonce, 'facebook_master_inner_custom_box' ) )
      return $post_id;

  // If this is an autosave, our form has not been submitted, so we don't want to do anything.
  if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
      return $post_id;

  // Check the user's permissions.
  if ( 'page' == $_POST['post_type'] ) {

    if ( ! current_user_can( 'edit_page', $post_id ) )
        return $post_id;

  } else {

    if ( ! current_user_can( 'edit_post', $post_id ) )
        return $post_id;
  }

/* OK, its safe for us to save the data now. */

// Sanitize user input.
	$facebook_master_preview = sanitize_text_field( $_POST['facebook_master_preview'] );
	$facebook_master_align = sanitize_text_field( $_POST['facebook_master_align'] );
	$facebook_master_w = sanitize_text_field( $_POST['facebook_master_w'] );
	$facebook_master_h = sanitize_text_field( $_POST['facebook_master_h'] );
	$facebook_master_display = sanitize_text_field( $_POST['facebook_master_display'] );
	$facebook_master_link = sanitize_text_field( $_POST['facebook_master_link'] );
	$facebook_master_id = sanitize_text_field( $_POST['facebook_master_id'] );
	$facebook_master_header = sanitize_text_field( $_POST['facebook_master_header'] );
	$facebook_master_faces = sanitize_text_field( $_POST['facebook_master_faces'] );
	$facebook_master_stream = sanitize_text_field( $_POST['facebook_master_stream'] );
	$facebook_master_color = sanitize_text_field( $_POST['facebook_master_color'] );
	$facebook_master_border = sanitize_text_field( $_POST['facebook_master_border'] );

// Update the meta field in the database.
	update_post_meta( $post_id, 'facebook_master_preview', $facebook_master_preview );
	update_post_meta( $post_id, 'facebook_master_align', $facebook_master_align );
	update_post_meta( $post_id, 'facebook_master_w', $facebook_master_w );
	update_post_meta( $post_id, 'facebook_master_h', $facebook_master_h );
	update_post_meta( $post_id, 'facebook_master_display', $facebook_master_display );
	update_post_meta( $post_id, 'facebook_master_link', $facebook_master_link );
	update_post_meta( $post_id, 'facebook_master_id', $facebook_master_id );
	update_post_meta( $post_id, 'facebook_master_header', $facebook_master_header );
	update_post_meta( $post_id, 'facebook_master_faces', $facebook_master_faces );
	update_post_meta( $post_id, 'facebook_master_stream', $facebook_master_stream );
	update_post_meta( $post_id, 'facebook_master_color', $facebook_master_color );
	update_post_meta( $post_id, 'facebook_master_border', $facebook_master_border );
}
add_action( 'save_post', 'facebook_master_save_postdata' );

//////////////////////////
// SHORTCODE START HERE //
//////////////////////////
function facebook_master_add_shortcode( $atts) {
global $post;

extract( shortcode_atts( array(
	'facebook_master_align'		=> 'facebook_master_align',
	'facebook_master_w'			=> 'facebook_master_w',
	'facebook_master_h'			=> 'facebook_master_h',
	'facebook_master_display'	=> 'facebook_master_display',
	'facebook_master_link'		=> 'facebook_master_link',
	'facebook_master_id'		=> 'facebook_master_id',
	'facebook_master_header'	=> 'facebook_master_header',
	'facebook_master_faces'		=> 'facebook_master_faces',
	'facebook_master_stream'	=> 'facebook_master_stream',
	'facebook_master_color'		=> 'facebook_master_color',
	'facebook_master_border'	=> 'facebook_master_border'
), $atts ) );

$facebook_master_align = get_post_meta($post->ID, $facebook_master_align, true);
$facebook_master_w = get_post_meta($post->ID, $facebook_master_w, true);
$facebook_master_h = get_post_meta($post->ID, $facebook_master_h, true);
$facebook_master_display = get_post_meta($post->ID, $facebook_master_display, true);
$facebook_master_link = get_post_meta($post->ID, $facebook_master_link, true);
$facebook_master_id = get_post_meta($post->ID, $facebook_master_id, true);
$facebook_master_header = get_post_meta($post->ID, $facebook_master_header, true);
$facebook_master_faces = get_post_meta($post->ID, $facebook_master_faces, true);
$facebook_master_stream = get_post_meta($post->ID, $facebook_master_stream, true);
$facebook_master_color = get_post_meta($post->ID, $facebook_master_color, true);
$facebook_master_border = get_post_meta($post->ID, $facebook_master_border, true);

if($facebook_master_display == "on"){
	// Display Facebook Header
		if ( $facebook_master_header == "on" ) 
		$facebook_master_header = "true";
		else {
		$facebook_master_header = "false";
		}
	// Display Facebook Faces
		if ( $facebook_master_faces == "on" ) 
		$facebook_master_faces = "true";
		else {
		$facebook_master_faces = "false";
			}
	// Display Facebook Stream
		if ( $facebook_master_stream == "on" ) 
		$facebook_master_stream = "true";
		else {
		$facebook_master_stream = "false";
			}
	// Display Facebook Color
		if ( $facebook_master_color == "on" ) 
		$facebook_master_color = "light";
		else {
		$facebook_master_color = "dark";
			}
	// Display Facebook Border
		if ( $facebook_master_border == "on" ) 
		$facebook_master_border = "true";
		else {
		$facebook_master_border = "false";
			}
$facebook_master_spacer = "'";
$facebook_master_create_display = '<div class="fb-like-box" data-href="'.$facebook_master_link.'" data-show-faces="'.$facebook_master_faces.'" data-colorscheme="'.$facebook_master_color.'" data-stream="'.$facebook_master_stream.'" data-show-border="'.$facebook_master_border.'" data-header="'.$facebook_master_header.'"></div>' .
			'<div id="fb-root"></div>' .
			'<script>(function(d, s, id) {' .
			'var js, fjs = d.getElementsByTagName(s)[0];' .
			'if (d.getElementById(id)) return;' .
			'js = d.createElement(s); js.id = id;' .
			'js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId='.$facebook_master_id.'";' .
			'fjs.parentNode.insertBefore(js, fjs);' .
			'}(document, '.$facebook_master_spacer.'script'.$facebook_master_spacer.', '.$facebook_master_spacer.'facebook-jssdk'.$facebook_master_spacer.'));</script>';
}
else{
$facebook_master_create_display = false;
}

return '<div style="position: relative; float: '.$facebook_master_align.'; width:'.$facebook_master_w.'px !important; height:'.$facebook_master_h.'px !important; padding:5px;">' .
	$facebook_master_create_display.
	'</div>';
}

add_shortcode('facebook-master', 'facebook_master_add_shortcode');