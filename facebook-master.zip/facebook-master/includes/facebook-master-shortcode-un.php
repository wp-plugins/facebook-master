<?php
function facebook_master_shortcode_un( $atts ){
//Prepare facebook Photos
if ( get_option('facebook_master_un_show_viral') == 'true' ){
$facebookmaster_url = "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
$facebookmasterspacer ="'";
$facebook_master_un_show_viral_create = '<div id="fb-root"></div>' .
			'<script>(function(d, s, id) {' .
			'var js, fjs = d.getElementsByTagName(s)[0];' .
			'if (d.getElementById(id)) return;' .
			'js = d.createElement(s); js.id = id;' .
			'js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=";' .
			'fjs.parentNode.insertBefore(js, fjs);' .
			'}(document, '.$facebookmasterspacer.'script'.$facebookmasterspacer.', '.$facebookmasterspacer.'facebook-jssdk'.$facebookmasterspacer.'));</script>' .
			'<div class="fb-like" data-href="'.$facebookmaster_url.'" data-layout="button_count" data-action="like" data-show-faces="false" data-share="true"></div>';
}
else{
$facebook_master_un_show_viral_create = false;
}

return $facebook_master_un_show_viral_create;
}
add_shortcode('facebook-master-un', 'facebook_master_shortcode_un');
?>