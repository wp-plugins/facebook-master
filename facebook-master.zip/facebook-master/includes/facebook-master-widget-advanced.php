<?php
//Hook Widget
add_action( 'widgets_init', 'facebook_master_widget_advanced' );

//Register Widget
function facebook_master_widget_advanced() {
register_widget( 'facebook_master_widget_advanced' );
}

add_action( 'wp_enqueue_scripts', 'facebook_master_wacss' );
//load css
function facebook_master_wacss() {
	wp_register_style( 'facebook_master_wacss', plugins_url('facebook-master-style.css', __FILE__) );
	wp_enqueue_style( 'facebook_master_wacss' );
}

class facebook_master_widget_advanced extends WP_Widget {
	function facebook_master_widget_advanced() {
	$widget_ops = array( 'classname' => 'Facebook Master Advanced', 'description' => __('Perfect to display your Facebook Fan Page or Application with full control over visual options. Mobile Responsive. ', 'facebook_master') );
	$control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'facebook_master_widget_advanced' );
	$this->WP_Widget( 'facebook_master_widget_advanced', __('Facebook Master Advanced', 'facebook _master'), $widget_ops, $control_ops );
	}
	
	function widget( $args, $instance ) {
		extract( $args );
		//Variables from the widget settings.
		$facebook_master_title = isset( $instance['facebook_master_title'] ) ? $instance['facebook_master_title'] :false;
		$facebook_master_title_new = isset( $instance['facebook_master_title_new'] ) ? $instance['facebook_master_title_new'] :false;
		$facebookmasterspacer ="'";
		$show_facebookmaster = isset( $instance['show_facebookmaster'] ) ? $instance['show_facebookmaster'] :false;
		$facebookmaster_page = $instance['facebookmaster_page'];
		$facebookmaster_appid = $instance['facebookmaster_appid'];
		$show_facebookmaster_header = isset( $instance['show_facebookmaster_header'] ) ? $instance['show_facebookmaster_header'] :false;
		$show_facebookmaster_faces = isset( $instance['show_facebookmaster_faces'] ) ? $instance['show_facebookmaster_faces'] :false;
		$show_facebookmaster_stream = isset( $instance['show_facebookmaster_stream'] ) ? $instance['show_facebookmaster_stream'] :false;
		$show_facebookmaster_color = isset( $instance['show_facebookmaster_color'] ) ? $instance['show_facebookmaster_color'] :false;
		$show_facebookmaster_border = isset( $instance['show_facebookmaster_border'] ) ? $instance['show_facebookmaster_border'] :false;
		$show_facebookmaster_mobile = isset( $instance['show_facebookmaster_mobile'] ) ? $instance['show_facebookmaster_mobile'] :false;
		echo $before_widget;
		
	// Display the widget title
	if ( $facebook_master_title ){
		if (empty ($facebook_master_title_new)){
		$facebook_master_title_new = get_option('facebook_master_master_name');
		}
		echo $before_title . $facebook_master_title_new . $after_title;
	}
	else{
	}
	// Display Facebook Header
		if ( $show_facebookmaster_header ){
		$show_facebookmaster_header = "true";
		}
		else {
		$show_facebookmaster_header = "false";
		}
	// Display Facebook Faces
		if ( $show_facebookmaster_faces ){
		$show_facebookmaster_faces = "true";
		}
		else {
		$show_facebookmaster_faces = "false";
		}
	// Display Facebook Stream
		if ( $show_facebookmaster_stream ){
		$show_facebookmaster_stream = "true";
		}
		else {
		$show_facebookmaster_stream = "false";
		}
	// Display Facebook Color
		if ( $show_facebookmaster_color ){
		$show_facebookmaster_color = "light";
		}
		else {
		$show_facebookmaster_color = "dark";
		}
	// Display Facebook Border
		if ( $show_facebookmaster_border ){
		$show_facebookmaster_border = "true";
		}
		else {
		$show_facebookmaster_border = "false";
		}
	//Display Faceboook Master
		if ( $show_facebookmaster ){
		echo '<div id="fb-root"></div>' .
			'<script>(function(d, s, id) {' .
			'var js, fjs = d.getElementsByTagName(s)[0];' .
			'if (d.getElementById(id)) return;' .
			'js = d.createElement(s); js.id = id;' .
			'js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId='.$facebookmaster_appid.'";' .
			'fjs.parentNode.insertBefore(js, fjs);' .
			'}(document, '.$facebookmasterspacer.'script'.$facebookmasterspacer.', '.$facebookmasterspacer.'facebook-jssdk'.$facebookmasterspacer.'));</script>' .
			'<div class="fb-like-box" data-href="'.$facebookmaster_page.'" data-show-faces="'.$show_facebookmaster_faces.'" data-colorscheme="'.$show_facebookmaster_color.'" data-stream="'.$show_facebookmaster_stream.'" data-show-border="'.$show_facebookmaster_border.'" data-header="'.$show_facebookmaster_header.'"></div>';
			}
			else{
			}
	echo $after_widget;
	}
	//Update the widget
	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		//Strip tags from title and name to remove HTML
		$instance['facebook_master_title'] = strip_tags( $new_instance['facebook_master_title'] );
		$instance['facebook_master_title_new'] = $new_instance['facebook_master_title_new'];
		$instance['show_facebookmaster'] = $new_instance['show_facebookmaster'];
		$instance['facebookmaster_page'] = $new_instance['facebookmaster_page'];
		$instance['facebookmaster_appid'] = $new_instance['facebookmaster_appid'];
		$instance['show_facebookmaster_header'] = $new_instance['show_facebookmaster_header'];
		$instance['show_facebookmaster_faces'] = $new_instance['show_facebookmaster_faces'];
		$instance['show_facebookmaster_stream'] = $new_instance['show_facebookmaster_stream'];
		$instance['show_facebookmaster_color'] = $new_instance['show_facebookmaster_color'];
		$instance['show_facebookmaster_border'] = $new_instance['show_facebookmaster_border'];
		$instance['show_facebookmaster_mobile'] = $new_instance['show_facebookmaster_mobile'];
		return $instance;
	}
	function form( $instance ) {
	//Set up some default widget settings.
	$defaults = array( 'facebook_master_title_new' => __('Facebook Master', 'facebook_master'), 'facebook_master_title' => true, 'facebook_master_title_new' => false, 'show_facebookmaster' => true, 'facebookmaster_page' => false, 'facebookmaster_appid' => false, 'show_facebookmaster_header' => true, 'show_facebookmaster_faces' => true, 'show_facebookmaster_stream' => true, 'show_facebookmaster_color' => true, 'show_facebookmaster_border' => true, 'show_facebookmaster_mobile' => true );
	$instance = wp_parse_args( (array) $instance, $defaults );
	?>
		<br>
		<b>Check the buttons to be displayed:</b>
	<p>
	<img src="<?php echo plugins_url('../images/techgasp-minilogo-16.png', __FILE__); ?>" style="float:left; height:16px; vertical-align:middle;" />
	&nbsp;
	<input type="checkbox" <?php checked( (bool) $instance['facebook_master_title'], true ); ?> id="<?php echo $this->get_field_id( 'facebook_master_title' ); ?>" name="<?php echo $this->get_field_name( 'facebook_master_title' ); ?>" />
	<label for="<?php echo $this->get_field_id( 'facebook_master_title' ); ?>"><b><?php _e('Display Widget Title', 'facebook_master'); ?></b></label></br>
	</p>
	<p>
	<label for="<?php echo $this->get_field_id( 'facebook_master_title_new' ); ?>"><?php _e('Change Title:', 'facebook_master'); ?></label>
	<br>
	<input id="<?php echo $this->get_field_id( 'facebook_master_title_new' ); ?>" name="<?php echo $this->get_field_name( 'facebook_master_title_new' ); ?>" value="<?php echo $instance['facebook_master_title_new']; ?>" style="width:auto;" />
	</p>
<div style="background: url(<?php echo plugins_url('../images/techgasp-hr.png', __FILE__); ?>) repeat-x; height: 10px"></div>
	<p>
	<img src="<?php echo plugins_url('../images/techgasp-minilogo-16.png', __FILE__); ?>" style="float:left; height:16px; vertical-align:middle;" />
	&nbsp;
	<input type="checkbox" <?php checked( (bool) $instance['show_facebookmaster'], true ); ?> id="<?php echo $this->get_field_id( 'show_facebookmaster' ); ?>" name="<?php echo $this->get_field_name( 'show_facebookmaster' ); ?>" />
	<label for="<?php echo $this->get_field_id( 'show_facebookmaster' ); ?>"><b><?php _e('Display Social Plugin', 'facebook_master'); ?></b></label></br>
	</p>
	<p>
	<label for="<?php echo $this->get_field_id( 'facebookmaster_page' ); ?>"><?php _e('Facebook Fan Page Link:', 'facebook_master'); ?></label></br>
	<input id="<?php echo $this->get_field_id( 'facebookmaster_page' ); ?>" name="<?php echo $this->get_field_name( 'facebookmaster_page' ); ?>" value="<?php echo $instance['facebookmaster_page']; ?>" style="width:auto;" />
	</p>
	<div class="description">Facebook Fan Page Link, ie <b>https://www.facebook.com/techgasp</b></div>
	<p>
	<label for="<?php echo $this->get_field_id( 'facebookmaster_appid' ); ?>"><?php _e('optional, Facebook App ID:', 'facebook_master'); ?></label></br>
	<input id="<?php echo $this->get_field_id( 'facebookmaster_appid' ); ?>" name="<?php echo $this->get_field_name( 'facebookmaster_appid' ); ?>" value="<?php echo $instance['facebookmaster_appid']; ?>" style="width:auto;" />
	</p>
	<div class="description">if you have a Facebook Application associated with your Fan Page, insert APP ID number here</div>
	<p>
	<img src="<?php echo plugins_url('../images/techgasp-minilogo-16.png', __FILE__); ?>" style="float:left; height:16px; vertical-align:middle;" />
	&nbsp;
	<input type="checkbox" <?php checked( (bool) $instance['show_facebookmaster_header'], true ); ?> id="<?php echo $this->get_field_id( 'show_facebookmaster_header' ); ?>" name="<?php echo $this->get_field_name( 'show_facebookmaster_header' ); ?>" />
	<label for="<?php echo $this->get_field_id( 'show_facebookmaster_header' ); ?>"><b><?php _e('Display Plugin Header', 'facebook_master'); ?></b></label></br>
	</p>
	<p>
	<img src="<?php echo plugins_url('../images/techgasp-minilogo-16.png', __FILE__); ?>" style="float:left; height:16px; vertical-align:middle;" />
	&nbsp;
	<input type="checkbox" <?php checked( (bool) $instance['show_facebookmaster_faces'], true ); ?> id="<?php echo $this->get_field_id( 'show_facebookmaster_faces' ); ?>" name="<?php echo $this->get_field_name( 'show_facebookmaster_faces' ); ?>" />
	<label for="<?php echo $this->get_field_id( 'show_facebookmaster_faces' ); ?>"><b><?php _e('Display Facebook User Faces', 'facebook_master'); ?></b></label></br>
	</p>
	<p>
	<img src="<?php echo plugins_url('../images/techgasp-minilogo-16.png', __FILE__); ?>" style="float:left; height:16px; vertical-align:middle;" />
	&nbsp;
	<input type="checkbox" <?php checked( (bool) $instance['show_facebookmaster_stream'], true ); ?> id="<?php echo $this->get_field_id( 'show_facebookmaster_stream' ); ?>" name="<?php echo $this->get_field_name( 'show_facebookmaster_stream' ); ?>" />
	<label for="<?php echo $this->get_field_id( 'show_facebookmaster_stream' ); ?>"><b><?php _e('Display Facebook Stream', 'facebook_master'); ?></b></label></br>
	</p>
	<p>
	<img src="<?php echo plugins_url('../images/techgasp-minilogo-16.png', __FILE__); ?>" style="float:left; height:16px; vertical-align:middle;" />
	&nbsp;
	<input type="checkbox" <?php checked( (bool) $instance['show_facebookmaster_color'], true ); ?> id="<?php echo $this->get_field_id( 'show_facebookmaster_color' ); ?>" name="<?php echo $this->get_field_name( 'show_facebookmaster_color' ); ?>" />
	<label for="<?php echo $this->get_field_id( 'show_facebookmaster_color' ); ?>"><b><?php _e('Color Scheme', 'facebook_master'); ?></b></label></br>
	</p>
	<div class="description">Color Scheme: if activated Light, if disabled Dark</div>
	<p>
	<img src="<?php echo plugins_url('../images/techgasp-minilogo-16.png', __FILE__); ?>" style="float:left; height:16px; vertical-align:middle;" />
	&nbsp;
	<input type="checkbox" <?php checked( (bool) $instance['show_facebookmaster_border'], true ); ?> id="<?php echo $this->get_field_id( 'show_facebookmaster_border' ); ?>" name="<?php echo $this->get_field_name( 'show_facebookmaster_border' ); ?>" />
	<label for="<?php echo $this->get_field_id( 'show_facebookmaster_border' ); ?>"><b><?php _e('Display Plugin Border', 'facebook_master'); ?></b></label></br>
	</p>
	<div class="description">Plugin Border: if activated show border, if disabled hide border</div>
	<p>
	<img src="<?php echo plugins_url('../images/techgasp-minilogo-16.png', __FILE__); ?>" style="float:left; height:16px; vertical-align:middle;" />
	&nbsp;
	<input type="checkbox" <?php checked( (bool) $instance['show_facebookmaster_mobile'], true ); ?> id="<?php echo $this->get_field_id( 'show_facebookmaster_mobile' ); ?>" name="<?php echo $this->get_field_name( 'show_facebookmaster_mobile' ); ?>" />
	<label for="<?php echo $this->get_field_id( 'show_facebookmaster_mobile' ); ?>"><b><?php _e('Mobile Responsive', 'facebook_master'); ?></b></label></br>
	</p>
	<div class="description">Fully Mobile Responsive: default is activated for perfect display on mobile devices</div>
	<br>
<div style="background: url(<?php echo plugins_url('../images/techgasp-hr.png', __FILE__); ?>) repeat-x; height: 10px"></div>
	<p>
	<img src="<?php echo plugins_url('../images/techgasp-minilogo-16.png', __FILE__); ?>" style="float:left; width:16px; vertical-align:middle;" />
	&nbsp;
	<b>Facebook Master Website</b>
	</p>
	<p><a class="button-secondary" href="http://wordpress.techgasp.com/facebook-master/" target="_blank" title="Facebook Master Info Page">Info Page</a> <a class="button-secondary" href="http://wordpress.techgasp.com/facebook-master-documentation/" target="_blank" title="Facebook Master Documentation">Documentation</a> <a class="button-primary" href="http://wordpress.org/plugins/facebook-master/" target="_blank" title="Facebook Master Wordpress">RATE US *****</a></p>
	<?php
	}
 }
?>